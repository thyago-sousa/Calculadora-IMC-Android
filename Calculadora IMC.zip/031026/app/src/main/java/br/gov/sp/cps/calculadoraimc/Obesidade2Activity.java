package br.gov.sp.cps.calculadoraimc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Obesidade2Activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obesidade2);

        String nome = getIntent().getStringExtra("NOME");
        String peso = getIntent().getStringExtra("PESO");
        String altura = getIntent().getStringExtra("ALTURA");
        double imc = getIntent().getDoubleExtra("RESULTADO_IMC", 0);

        ((TextView)findViewById(R.id.txtValorOb2)).setText(String.format("%.2f", imc));
        ((TextView)findViewById(R.id.txtResumoOb2)).setText(nome + "\nPeso: " + peso + "kg | Altura: " + altura + "m");

        findViewById(R.id.btnVoltarOb2).setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }
}