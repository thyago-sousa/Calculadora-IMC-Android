package br.gov.sp.cps.calculadoraimc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SobrepesoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sobrepeso);

        String nome = getIntent().getStringExtra("NOME");
        String peso = getIntent().getStringExtra("PESO");
        String altura = getIntent().getStringExtra("ALTURA");
        double imc = getIntent().getDoubleExtra("RESULTADO_IMC", 0);

        ((TextView)findViewById(R.id.txtValorSobre)).setText(String.format("%.2f", imc));
        ((TextView)findViewById(R.id.txtResumoSobre)).setText(nome + "\nPeso: " + peso + "kg | Altura: " + altura + "m");

        findViewById(R.id.btnVoltarSobre).setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }
}